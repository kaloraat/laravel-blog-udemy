@section('meta-title') {{ $blog->meta_title }} - New IT Books @endsection
@section('meta-desc') {{ $blog->meta_desc }} @endsection
@section('meta-author') Ryan Dhungel @endsection