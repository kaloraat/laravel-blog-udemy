<?php $__env->startSection('content'); ?>

<main>
    <div class="jumbotron">
        <div class="container">
            <div class="col-sm-8">
                <h1><?php echo e($user->name); ?></h1>
                <p><?php echo e($user->role->name); ?></p>
                <?php if($user->blog->count() > 0): ?> <button class="btn btn-primary btn-xs"><?php echo e($user->blog->count()); ?> Blogs</button> <?php endif; ?>
            </div>
            <div class="col-sm-4">
            <br><br>
                <img class="img-circle" height="100" width="100" src="/images/<?php echo e($user->photo ? $user->photo->photo : 'default.png'); ?>" alt="">
            </div>
        </div>
    </div>

    <div class="col-sm-7">
           <?php if($user->blog->count() > 0): ?>
               <h1>Latest Blogs by <small><a href="<?php echo e(route('users.show', $user->username)); ?>"><?php echo e($user->name); ?></a></small></h1>
               <hr>
               <?php $__currentLoopData = $user->blog->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                   <h2><a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>"><?php echo e($blog->title); ?></a></h2>
                   <?php echo str_limit($blog->body, 200); ?> <a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>">Read more</a>

                   <p>
                    Posted <strong><?php echo e($blog->created_at->diffForHumans()); ?></strong> 

                    <?php if($blog->category): ?>
                         <?php $__currentLoopData = $blog->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> <i class="fa fa-btn fa-cubes"></i> <a href="<?php echo e(route('categories.show', $category->slug)); ?>"><?php echo e($category->name); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                     <?php endif; ?> 
                    </p>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
           <?php endif; ?>
        </div>

        <div class="col-sm-5">
            <?php echo $__env->make('partials.user-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>