<?php echo $__env->make('partials.meta-static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div id="welcome">
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    New IT Books
                </div>

                <div class="links">
                    <a href="<?php echo e(url('/blog')); ?>">Blog</a>
                    <a href="<?php echo e(url('/login')); ?>">Login</a>
                    <a href="<?php echo e(url('/register')); ?>">Register</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>