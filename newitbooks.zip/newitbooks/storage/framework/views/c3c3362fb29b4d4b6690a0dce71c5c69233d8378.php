<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbothon">
            <h1><?php echo e($user->count()); ?> Users on NewITBooks</h1>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="page-header">Recent Users</h1>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Joined</th>
                                <th>Role</th>
                                <th>Action</th>
                                <th>Destroy</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('users.show', $user->username)); ?>"><?php echo e($user->name); ?></a></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                <td>
                                    <?php echo e(Form::model($user, ['method' => 'PATCH', 'action' => ['UserController@update', $user->id]])); ?>

                                            <?php echo Form::select("role_id", ['1' => 'Administrator', '2' => 'Author', '3' => 'Subscriber'], null, ['class' => 'btn btn-primary']); ?> </td>
                                        <td><?php echo e(Form::submit("Update", ['class' => 'btn btn-success btn-xs'])); ?>

                                    <?php echo e(Form::close()); ?>

                                </td>
                                <td>
                                <?php echo e(Form::model($user, ['method' => 'DELETE', 'action' => ['UserController@destroy', $user->id]])); ?>

                                        <?php echo e(Form::submit("Delete", ['class' => 'btn btn-danger btn-xs'])); ?>

                                    <?php echo e(Form::close()); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>