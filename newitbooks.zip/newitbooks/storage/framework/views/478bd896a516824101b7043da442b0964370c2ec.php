<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid img-container">
        <div class="jumbotron">
            <h1>Featured Images</h1>
        </div>
        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li style="list-style:none;">
                <img height="100" src="/images/<?php echo e($photo->photo); ?>" alt="">
                <?php echo e(Form::open(['method' => 'DELETE', 'action' => ['PhotosController@destroy', $photo->id]])); ?>

                    <?php echo Form::submit("Delete Photo", ['class' => 'btn btn-danger']); ?>

                <?php echo e(Form::close()); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>