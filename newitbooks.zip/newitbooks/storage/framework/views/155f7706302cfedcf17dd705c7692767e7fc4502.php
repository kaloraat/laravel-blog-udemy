<?php $__env->startSection('content'); ?>

<main class="container-fluid">

<div class="container-fluid">
        <div class="jumbotron">
            <div class="container">
                <div class="col-sm-8">
                    <h1>Hello, <?php echo e(Auth::user()->name); ?></h1>
                    <p><?php echo e(Auth::user()->role->name); ?></p>

                    <?php if(Auth::user()->role->id == 2): ?>
                        <button class="btn btn-primary link btn-xs"><a style="color:#fff;" href="<?php echo e(url('/blog/create')); ?>">Create Blog</a></button>
                    <?php endif; ?>
        
                    <button class="btn btn-success link btn-xs"><a style="color:#fff;" href="<?php echo e(action('UserController@edit', Auth::user()->username)); ?>"> Profile Settings</a></button>
                </div>
                <div class="col-sm-4">
                <br><br>
                    <img class="img-circle" height="100" width="100" src="/images/<?php echo e(Auth::user()->photo ? Auth::user()->photo->photo : 'default.png'); ?>" alt="">
                </div>
            </div>
        </div>
    </div>


    <div class="col-sm-7">
        <?php if($user = Auth::user()): ?>
            <?php if($user->blog): ?>
            <h1 class="page-header">Latest Blogs</h1>
                <ul>
                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php if($blog->user_id == $user->id): ?>
                            <li style="list-style-type:none;">
                                <button class="btn btn-success btn-xs"><?php echo e($blog->status == 0 ? 'Draft' : 'Published'); ?></button>
                                <a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>"><?php echo e($blog->title); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <div class="col-sm-5">
        <?php echo $__env->make('partials.user-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>


</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>