<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Edit Category</h1>
        </div>
        <div class="col-sm-10 col-sm-offset-1">
            <?php echo Form::model($category,['method' => 'PATCH', 'action' => ['CategoryController@update', $category->id]]); ?>

                <div class="form-group">
                    <?php echo Form::label("name", "Name:"); ?>

                    <?php echo Form::text("name", null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::submit("Edit Category", ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>


            <?php echo Form::open(['method' => 'DELETE', 'action' => ['CategoryController@destroy', $category->id]]); ?>

                <?php echo Form::submit("Delete Category", ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>