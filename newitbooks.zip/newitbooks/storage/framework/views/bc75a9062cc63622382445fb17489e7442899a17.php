<section>
  <div class="jumbotron white">
    <div class="container">
      <h1 class="head-gradient1">Custom Web Development</h1>
    </div>
  </div>
</section>