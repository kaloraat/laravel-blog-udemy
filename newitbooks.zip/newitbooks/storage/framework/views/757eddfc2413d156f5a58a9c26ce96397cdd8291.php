<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Contact page</h1>
        </div>

        <div class="col-sm-8 col-sm-offset-2">
            <?php echo e(Form::open(['method' => 'POST', 'action' => 'MailController@send'])); ?>

            <?php echo $__env->make('partials.error-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="form-group">
                    <?php echo e(Form::label("name", "Name")); ?>

                    <?php echo e(Form::text("name", null, ['class' => 'form-control', 'placeholder' => 'Your name'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label("email", "Email")); ?>

                    <?php echo e(Form::email("email", null, ['class' => 'form-control', 'placeholder' => 'Your email'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label("subject", "Subject")); ?>

                    <?php echo e(Form::text("subject", null, ['class' => 'form-control', 'placeholder' => 'Subject'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label("mail_message", "Message")); ?>

                    <?php echo e(Form::textarea("mail_message", null, ['class' => 'form-control', 'placeholder' => 'Your message'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::submit("Send", ['class' => 'btn btn-primary col-sm-12'])); ?>

                </div>
            <?php echo e(Form::close()); ?>

        </div>
        <br>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>