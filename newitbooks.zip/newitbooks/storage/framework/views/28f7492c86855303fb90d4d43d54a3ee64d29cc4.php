<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.meta-dynamic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="container-fluid">
    <article>

        <div class="col-sm-12">
            <?php if($blog->photo): ?>
            <img class="img-responsive featured_image" src="/images/<?php echo e($blog->photo ? $blog->photo->photo : ''); ?>" alt="<?php echo e(str_limit($blog->title, 50)); ?>"><br>
            <?php endif; ?>
        </div>

        <div class="container-fluid">

            <div class="jumbotron">
                <h1 class="text-center"><?php echo e($blog->title); ?></h1> <?php if(Auth::user() ? Auth::user()->role_id ==1 || Auth::user()->id == $blog->user_id : ''): ?> <a style="float:right;" href="<?php echo e(action('BlogController@edit', $blog->id)); ?>">Edit</a> <?php endif; ?>

            </div>
            <div class="col-sm-8 col-sm-offset-2">
                <?php echo $blog->body; ?>

                <hr>
                <p>

                    <?php if($blog->user): ?>
                         <i class="fa fa-btn fa-user"></i> Blog by <a href="<?php echo e(route('users.show', $blog->user->username)); ?>"><?php echo e($blog->user->name); ?></a> <i class="fa fa-btn fa-clock-o"></i>
                     <?php endif; ?> 

                    Posted <strong><?php echo e($blog->created_at->diffForHumans()); ?></strong> 

                    <?php if($blog->category): ?>
                         <?php $__currentLoopData = $blog->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> <i class="fa fa-btn fa-cubes"></i> <a href="<?php echo e(route('categories.show', $category->slug)); ?>"><?php echo e($category->name); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                     <?php endif; ?> 

                    </p>
            </div>

            <?php echo $__env->make('partials.disqus', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>                    

        </article>
    </div>


</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>