<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Deleted blog posts</h1>
        </div>
        <div class="col-sm-8 col-sm-offset-2">
            <?php $__currentLoopData = $deletedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <article>
                    <h2><?php echo e($blog->title); ?></h2>
                    <p><?php echo e($blog->body); ?></p>
                    <?php echo Form::open(['method' => 'GET', 'action' => ['BlogController@restore', $blog->id]]); ?>

                        <div class="form-group">
                            <?php echo Form::submit("Restore Blog", ['class' => 'btn btn-primary']); ?>

                        </div>
                    <?php echo Form::close(); ?>


                    <?php echo Form::open(['method' => 'DELETE', 'action' => ['BlogController@destroyBlog', $blog->id]]); ?>

                        <div class="form-group">
                            <?php echo Form::submit("Destroy Blog", ['class' => 'btn btn-danger']); ?>

                        </div>
                    <?php echo Form::close(); ?>

                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>