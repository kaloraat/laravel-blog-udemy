<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1><?php echo e($category->name); ?></h1>
        </div>
        <h2><strong>Recent Blogs on <?php echo e($category->name); ?></strong></h2>
        <hr>
        <?php $__currentLoopData = $category->blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h2><a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>"><?php echo e($blog->title); ?></a></h2>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>