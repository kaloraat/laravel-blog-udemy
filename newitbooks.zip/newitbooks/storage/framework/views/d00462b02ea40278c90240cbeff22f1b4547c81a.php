<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Email from New IT Books</title>
    </head>

    <body style="padding: 0 10%;">
        <h1 style="text-align: center; background-color: #eee; color: #737373; padding: 10px;">New IT Books</h1>
        
        <blockquote>
            <h2>Hi <?php echo e($user->name); ?></h2>

            <h3>A new blog <a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>"><?php echo e($blog->title); ?></a> has been posted in newitbooks.com</h3>

            <h4>Category: <?php $__currentLoopData = $blog->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> <span><a href="<?php echo e(route('categories.show', $category->slug)); ?>"><strong><?php echo e($category->name); ?></strong></a></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?></h4>

            <p><a href="<?php echo e(action('BlogController@show', [$blog->slug])); ?>">Read full article ..</a></p>
        </blockquote>
        <h5 style="text-align: center; background-color: #eee; color: #737373; padding: 10px;">Note: This blog post might not have been officially published yet!</h5>

    </body>
</html>