<?php $__env->startSection('meta-title'); ?> <?php echo e($blog->meta_title); ?> - New IT Books <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta-desc'); ?> <?php echo e($blog->meta_desc); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta-author'); ?> Ryan Dhungel <?php $__env->stopSection(); ?>