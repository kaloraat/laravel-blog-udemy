<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Category</h1>
        </div>
        <div class="col-sm-8">
        <h2>Create</h2>
        <hr>
            <?php echo Form::open(['method' => 'POST', 'action' => 'CategoryController@store']); ?>

                <div class="form-group">
                <?php echo $__env->make('partials.error-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::label("name", "Name:"); ?>

                    <?php echo Form::text("name", null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::submit("Create a Category", ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>

        <div class="col-sm-4">
        <h2>List</h2>
        <hr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
               <li style="list-style-type:none;">
                    <a href="<?php echo e(route('categories.show', $category->slug)); ?>"><h3><?php echo e($category->name); ?></h3></a>
                    <?php echo Form::open(['method' => 'DELETE', 'action' => ['CategoryController@destroy', $category->id]]); ?>

                        <?php echo Form::submit("Delete", ['class' => 'btn btn-danger btn-xs']); ?>

                    <?php echo Form::close(); ?>

               </li>
               <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>