<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.tinymce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Create a blog post</h1>
        </div>
        <div class="col-sm-10 col-sm-offset-1">
            <?php echo Form::open(['method' => 'POST', 'action' => 'BlogController@store', 'files' => true]); ?>

                <div class="form-group">
                    <?php echo $__env->make('partials.error-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::label("title", "Title:"); ?>

                    <?php echo Form::text("title", null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label("body", "Body:"); ?>

                    <?php echo Form::textarea("body", null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label("photo_id", "Featured Image:"); ?>

                    <?php echo Form::file("photo_id", ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label("category_id", "Category:"); ?>

                    <?php echo Form::select("category_id[]", $categories, null, ['id' => 'tag_list', 'class' => 'form-control', 'multiple']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label("meta_desc", "Meta Description:"); ?>

                    <?php echo Form::text("meta_desc", null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::submit("Submit", ['class' => 'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

</main>

<?php echo $__env->make('partials.select-2-script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>