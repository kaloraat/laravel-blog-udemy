<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
        <h2><?php echo e($title); ?></h2>
        <p><?php echo e($content); ?></p>
    </body>
</html>