<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <h1><?php echo e($user->count()); ?> testing how many and latest users</h1>
        <div class="jumbotsron col-sm-6 col-sm-offset-3">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                
                    <h2>Latest user to join kaloraat</h2>
                    <p><?php echo e($user->name); ?></p>
                    <p><?php echo e($user->created_at->diffForHumans()); ?></p>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>


</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>