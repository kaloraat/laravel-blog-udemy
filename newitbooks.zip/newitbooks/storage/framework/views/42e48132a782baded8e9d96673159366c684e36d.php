<?php $__env->startSection('content'); ?>

<main class="container-fluid">

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Blog Categories</h1>
        </div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            
            <?php if($category->blog->count() > 0): ?>
                <h2><a href="<?php echo e(route('categories.show', $category->slug)); ?>"><?php echo e($category->name); ?></a></h2>
                <hr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>