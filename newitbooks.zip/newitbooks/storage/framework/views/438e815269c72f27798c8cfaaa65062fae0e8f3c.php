<?php if($user->about): ?>
    <div>
        <h2>About</h2>
        <hr>
        <p><?php echo e($user->about); ?></p>
    </div>
<?php endif; ?>

<div>
    <h2>URL</h2>
    <hr>
    <a href="<?php echo e($user->username); ?>">newitbooks.com/<?php echo e($user->username); ?></a>
</div>

<?php if($user->website): ?>
    <div>
        <h2>Website</h2>
        <hr>
        <a href="<?php echo e($user->website); ?>"><?php echo e($user->website); ?></a>
    </div>
<?php endif; ?>

<?php if($user->facebook || $user->twitter || $user->github): ?>
    <div>
        <h2>Get Social</h2>
        <hr>
        <ol class="list-unstyled">
            <?php if($user->facebook): ?>
                <li><a href="<?php echo e($user->facebook); ?>"><?php echo e($user->facebook); ?></a></li>
            <?php endif; ?>
            <?php if($user->twitter): ?>
                <li><a href="<?php echo e($user->twitter); ?>"><?php echo e($user->twitter); ?></a></li>
            <?php endif; ?>
            <?php if($user->github): ?>
                <li><a href="<?php echo e($user->github); ?>"><?php echo e($user->github); ?></a></li>
            <?php endif; ?>
        </ol>
    </div>
<?php endif; ?>